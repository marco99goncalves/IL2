/*
 * globals.h
 */

#ifndef GLOBALS_H
#define GLOBALS_H

#include "list.h"
#include "heap.h"

List*  roots;
Heap*  heap;

#endif
